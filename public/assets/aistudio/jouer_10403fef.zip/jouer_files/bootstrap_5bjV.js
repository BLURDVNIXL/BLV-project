import './pwa-install.js';
// Vieux navigateurs (iPhone avant iOS 15.4, Chrome avant 92) : « tableau.at(i) » manquant, le jeu plantait à l'ouverture
// des discussions (« N.chat.at is not a function », 30/10/2026). Ajouté avant le chargement du jeu (main.js, plus bas).
for (const P of [Array.prototype, String.prototype]) {
  if (!P.at) Object.defineProperty(P, 'at', { configurable: true, writable: true, value(i) { i = Math.trunc(i) || 0; if (i < 0) i += this.length; return i < 0 || i >= this.length ? undefined : this[i]; } });
}
const boot = document.getElementById('boot');
// L'import du jeu est asynchrone : window.load peut déjà être passé quand main.js s'évalue.
// Préparer le hors-ligne indépendamment du chargement de la 3D, sans retarder le jeu en ligne.
if ('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js', { updateViaCache: 'none' }).catch(() => {});
const message = boot.querySelector('[role="status"]');
const retry = boot.querySelector('button');
retry.onclick = () => location.reload();
const slow = setTimeout(() => {
  message.textContent = 'Le chargement prend du temps. Vérifie ta connexion puis réessaie si nécessaire.';
  retry.hidden = false;
}, 15000);
import('./main.js').then(() => boot.remove()).catch(() => {
  message.textContent = 'Le jeu n’a pas pu démarrer. Vérifie ta connexion puis réessaie. Ta sauvegarde est conservée.';
  retry.hidden = false;
}).finally(() => clearTimeout(slow));
